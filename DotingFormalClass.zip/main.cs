using System;

class MainClass {
  public static void Main (string[] args)
   {
    Console.Write("Skriv ett tal: ");
    string strNr = Console.ReadLine();
    int tal = int.Parse(strNr);
    Console.Write("Skriv nasta nummer: ");
    string strN = Console.ReadLine();
    int nummer = int.Parse(strN);
    Console.Write("Differensen och summan: ");
    Console.Write(tal - nummer + " ");
    Console.Write( tal + nummer);
    
  }
}