using System;

class MainClass {
  public static void Main (string[] args) {
    Console.Write("Skriv ditt förnamn: ");
    string förnamn = Console.ReadLine();
    Console.Write("Skriv ditt efternamn: ");
    string efternamn = Console.ReadLine();
    Console.Write("Ditt namn: ");
    Console.Write(förnamn + " " + efternamn);
  }
}